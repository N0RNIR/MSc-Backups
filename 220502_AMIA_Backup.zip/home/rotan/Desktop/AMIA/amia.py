# Project Title: "Automated computational workflow to prioritize potential resistance variants identified in HIV Integrase Subtype C and CRF02_AG" 
# This script is developed for the fufuillment for Masters at the South African National Bioinformatics Institute at the University of the Western Cape
# The project is funded by the Poliomyelitis Research Foundation and the UWC Ada & Bertie Levenstein Bursary Programme
# Currently any licensing and usage of this software is governed under the regulations of the afore mentioned parties

#Author:	Keaghan Brown (3687524) - MSc Bioinformatics Candidate (3687524@myuwc.ac.za)
#Author:	Ruben Cloete (Supervisor) - Lecturer at South African National Bioinformatics Institute (ruben@sanbi.ac.za)

import sys
from tkinter.filedialog import askopenfilename
sys.path.append("/home/rotan/Desktop/AMIA")
from MutIntro import Mutations
from ResidueContacts import MutantAnalysis
import logging
p = Mutations()
q = MutantAnalysis()

def __init__():
    pymol.cmd.reinitialize()
    three_letter ={'V': 'VAL', 'I': 'ILE', 'L': 'LEU', 'E': 'GLU', 'Q': 'GLN', 'D': 'ASP', 'N': 'ASN', 'H': 'HIS', 'W': 'TRP', 'F': 'PHE', 'Y': 'TYR', 'R': 'ARG', 'K': 'LYS', 'S': 'SER', 'T': 'THR', 'M': 'MET', 'A': 'ALA', 'G': 'GLY', 'P': 'PRO', 'C': 'CYS'}
    paramfile = askopenfilename(title='Select Parameter File')
    param_data = open(paramfile).read().split('\n')
    for i in param_data:
        if 'mutation_file' in i:
            mutantion_list_path = i.split('=')[1]
        if 'model_file' in i:
            model_file_path =  i.split('=')[1]
        if 'mutant_storage' in i:
            structure_storage_path = i.split('=')[1]
        if 'introduction_method' in i:
            introduction_mode = i.split('=')[1]
        if 'contacts_output' in i:
            contacts_ouput_folder = i.split('=')[1]
    logging.basicConfig(format = '%(asctime)s - %(levelname)s - %(message)s', filename = (structure_storage_path+ '/mutant_intro.log'), filemode='w',  level=logging.DEBUG)
    return mutantion_list_path, model_file_path, structure_storage_path, introduction_mode, contacts_ouput_folder

processing_param_file = __init__()
"""
p.process_mutant_list(processing_param_file[0])
modes = ''
if ',' in processing_param_file[3]:
    modes = processing_param_file[3].split(',')
else:
    modes = str(processing_param_file[3])
	
if "single" == modes:
	p.single_mutations(processing_param_file[1], processing_param_file[2])
	q.single_residue_contacts(processing_param_file[2],processing_param_file[1], processing_param_file[4])
elif "multiple" == modes:
	p.multi_mutations(processing_param_file[1], processing_param_file[2])
	q.multiple_residue_contacts(processing_param_file[2],processing_param_file[1], processing_param_file[4])
elif "single" and "multiple" in modes:
	p.single_mutations(processing_param_file[1], processing_param_file[2])
	q.single_residue_contacts(processing_param_file[2],processing_param_file[1], processing_param_file[4])
	p.multi_mutations(processing_param_file[1], processing_param_file[2])
	q.multiple_residue_contacts(processing_param_file[2],processing_param_file[1], processing_param_file[4])
"""
q.multiple_residue_contacts(processing_param_file[2],processing_param_file[1], processing_param_file[4])
