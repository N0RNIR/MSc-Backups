# Project Title: "Automated computational workflow to prioritize potential resistance variants identified in HIV Integrase Subtype C and CRF02_AG" 
# This script is developed for the fufuillment for Masters at the South African National Bioinformatics Institute at the University of the Western Cape
# The project is funded by the Poliomyelitis Research Foundation and the UWC Ada & Bertie Levenstein Bursary Programme
# Currently any licensing and usage of this software is governed under the regulations of the afore mentioned parties

#Author:	Keaghan Brown (3687524) - MSc Bioinformatics Candidate (3687524@myuwc.ac.za)
#Author:	Ruben Cloete (Supervisor) - Lecturer at South African National Bioinformatics Institute (ruben@sanbi.ac.za)

# This script completes the Second Objective for The Automated Computational Workflow to Prioritize Potential Resistance Variants Identified in HIV Integrase Subtype C and CRF02_AG
import os
import sys
import tkinter as tk 
from tkinter.filedialog import askopenfilename,  askdirectory
from Bio.PDB.PDBParser import PDBParser
from Bio.PDB.Polypeptide import PPBuilder
import ntpath
import warnings
from Bio import BiopythonWarning
warnings.simplefilter('ignore', BiopythonWarning)
sys.path.append("/home/rotan/Desktop/AMIA")
import re
from get_raw_distances import *
import itertools
from tabulate import tabulate
tabulate.PRESERVE_WHITESPACE = True
from tkinter import Tk
import logging
import pymol


class MutantAnalysis:
	
	def __init__(self):
		pymol.cmd.reinitialize()
		self.three_letter ={'V': 'VAL', 'I': 'ILE', 'L': 'LEU', 'E': 'GLU', 'Q': 'GLN', 'D': 'ASP', 'N': 'ASN', 'H': 'HIS', 'W': 'TRP', 'F': 'PHE', 'Y': 'TYR', 'R': 'ARG', 'K': 'LYS', 'S': 'SER', 'T': 'THR', 'M': 'MET', 'A': 'ALA', 'G': 'GLY', 'P': 'PRO', 'C': 'CYS'}
	
	def single_residue_contacts(self, mutant_folder, model, output):
		logging.info("RUNNING SINGLE MUTANT CONTACT ANALYSIS....")
		mutant_folder_path = mutant_folder
		model_path = model
		os.chdir(mutant_folder_path)
		table_dict2 = {"Mutant PDB" : [], "Wild - Type Contacts" : [],  "Mutant Contacts" : [],  "No. of Wild - Type Contacts" : [], "No. of Mutant Contacts" : []}
		data_file = open(output + '/single_intro_mutant_contacts.txt', 'w')
		data_file.write(tabulate(table_dict2, headers="keys", numalign = "center", stralign = "center") + '\n')
		for file in os.listdir():
			if '_' not in file and file.endswith('.pdb'):
				table_dict = {"Mutant PDB" : [], "Wild - Type Contacts" : [],  "Mutant Contacts" : [],  "No. of Wild - Type Contacts"  : [], "No. of Mutant Contacts" : []}
				mutant_contacts = {}
				model_contacts = {}
				table_dict.setdefault("Mutant PDB", []).append(file.split('.')[0])
				parser = PDBParser(PERMISSIVE=1)
				structure_id = ntpath.basename(file).split('.')[0]
				filename = ntpath.basename(file)
				structure = parser.get_structure(structure_id, filename)
				ppb=PPBuilder()
				ppb.build_peptides(structure)
				pymol.cmd.reinitialize()
				pymol.cmd.load(file)
				logging.info("Structure " + file + " has been loaded for contact analysis")
				mut_resi_pos =  file.split('.')[0]
				mut_resi_pos = mut_resi_pos[1:(len(mut_resi_pos)-1)]
				mutated_residue = file.split('.')[0]
				initial_residue = mutated_residue[0]
				mutated_residue = mutated_residue[len(mutated_residue)-1]
				cmd.select('mutant_pos_'  + str(mut_resi_pos) ,  'model ' + str(file.split('.')[0])+ ' and resn ' + str(self.three_letter[mutated_residue]) + '& resi ' +  str(mut_resi_pos))
				chains = cmd.get_chains(file.split('.')[0])
				sequences = []
				for pp in ppb.build_peptides(structure):
					sequence= pp.get_sequence()
					sequences.append(sequence)
				largest_seq =  ''
				for i in sequences:
					if len(i) > len(largest_seq):
						largest_seq = i
				pos_counter = 0
				pos_counter2 = 0
				for i in largest_seq:
					pos_counter +=1
					for j in chains:
						cmd.select('residue' + str(pos_counter)+str(j), 'resn ' + str(self.three_letter[i]) +   + '& chain ' + str(j))
						cmd.distance('mutant_h-bond' +  str(pos_counter)+str(j),  'mutant_pos_'  + str(mut_resi_pos), 'residue' + str(pos_counter)+str(j), "3.5", mode="2")
						D = get_raw_distances('mutant_h-bond' +  str(pos_counter)+str(j))
						mutant_contacts[str(i) + ';' + str(pos_counter)+ ','+str(j)] = (len(D))
				cmd.reinitialize()
				cmd.load(model_path)
				cmd.select('model_pos_'  + str(mut_resi_pos) ,  'model ' + str(ntpath.basename(model_path).split('.')[0])+ ' and resn ' + str(self.three_letter[initial_residue]) + '& resi ' +  str(mut_resi_pos))
				for k in largest_seq:
					pos_counter2 +=1
					for l in chains:
						cmd.select('model_residue' + str(pos_counter2)+str(l), 'resn ' + str(self.three_letter[k]) +  '& chain ' + str(l))
						cmd.distance('model_h-bond' +  str(pos_counter2)+str(l),  'model_pos_'  + str(mut_resi_pos), 'model_residue' + str(pos_counter2)+str(l), "3.5", mode="2")
						D2 = get_raw_distances('model_h-bond' +  str(pos_counter2)+str(l))
						model_contacts[str(k) + ';' + str(pos_counter2)+ ','+ str(l)] = (len(D2))
				for contact in model_contacts:
					if model_contacts[contact] > 0:
						table_dict.setdefault('Wild - Type Contacts', []).append(contact)
						table_dict.setdefault('# of Wild - Type Contacts', []).append(str(model_contacts[contact]))
				for contact2 in mutant_contacts:
					if mutant_contacts[contact2] > 0:
						table_dict.setdefault("Mutant Contacts", []).append(contact2)
						table_dict.setdefault("# of Mutant Contacts", []).append(str(mutant_contacts[contact2]))
				for i in table_dict["Wild - Type Contacts"]:
					if i not in table_dict["Mutant Contacts"] and i != '0':
						pos = table_dict["Wild - Type Contacts"].index(i)
						table_dict["Mutant Contacts"].insert(pos, '0')
						table_dict["# of Mutant Contacts"].insert(pos, '0')
				for j in table_dict["Mutant Contacts"]:
					if j != '0' and j not in table_dict["Wild - Type Contacts"]  :
						pos = table_dict["Mutant Contacts"].index(j)
						table_dict["Wild - Type Contacts"].insert(pos, '0')
						table_dict["# of Wild - Type Contacts"].insert(pos, '0')
				new_headers = []
				for key in table_dict:
					new_key = ''
					for i in key:
						new_key += ' '
					new_headers.append(new_key)
				data_file = open(output + '/single_intro_mutant_contacts.txt', 'a')
				data_file.write(tabulate(table_dict, headers= new_headers, numalign = "center", stralign = "center", tablefmt = "plain")+ '\n' )
				data_file.close()
			
	def multiple_residue_contacts(self, mutant_folder, model, output):
		logging.info("RUNNING MULTIPLE MUTANT CONTACT ANALYSIS....")
		mutant_folder_path = mutant_folder
		model_path = model
		os.chdir(mutant_folder_path)
		table_dict2 = {"Mutant PDB" : [], "Wild - Type Contacts" : [],  "Mutant Contacts" : [],  "No. of Wild - Type Contacts" : [], "No. of Mutant Contacts" : []}
		data_file = open(output + '/multiple_intro_mutant_contacts.txt', 'w')
		data_file.write(tabulate(table_dict2, headers="keys", numalign = "center", stralign = "center") + '\n')
		for file in os.listdir():
			if '_' in file and file.endswith('.pdb'):
				mutations_list_to_analyze = file.split('.')[0].split('_')
				while '' in mutations_list_to_analyze:
					mutations_list_to_analyze.remove('')
				parser = PDBParser(PERMISSIVE=1)
				structure_id = ntpath.basename(file).split('.')[0]
				filename = ntpath.basename(file)
				structure = parser.get_structure(structure_id, filename)
				ppb=PPBuilder()
				ppb.build_peptides(structure)
				logging.info("Structure " + file + " has been loaded for contact analysis")
				sequences = []
				for pp in ppb.build_peptides(structure):
					sequence= pp.get_sequence()
					sequences.append(sequence)
				largest_seq =  ''
				for i in sequences:
					if len(i) > len(largest_seq):
						largest_seq = i
				for mutation in mutations_list_to_analyze:
					mutant_contacts = {}
					model_contacts = {}
					multi_mutant_contact_dict = {"Mutant PDB" : [], "Wild - Type Contacts" : [],  "Mutant Contacts" : [],  "No. of Wild - Type Contacts" : [], "No. of Mutant Contacts" : []}
					logging.info("Mutation " + mutation + " is being analysed for contacts....")
					multi_mutant_contact_dict.setdefault("Mutant PDB", []).append(mutation)
					cmd.reinitialize()
					mut_resi_pos = mutation[1:(len(mutation)-1)]
					initial_residue = mutation[0]
					mutated_residue = mutation[len(mutation)-1]
					cmd.load(file)
					chains = pymol.cmd.get_chains(file.split('.')[0])
					pos_counter = 0
					pos_counter2 = 0
					cmd.select('mutant_pos_'  + str(mut_resi_pos) , 'resn ' + str(self.three_letter[mutated_residue]) + ' and resi ' +  str(mut_resi_pos)) 
					for k in largest_seq:
						pos_counter +=1
						for l in chains:
							cmd.select('residue' + str(pos_counter) + str(l), 'resn ' + str(self.three_letter[k]) + ' and resi ' +  str(pos_counter) + ' and chain ' + str(l))
							cmd.distance('mutant_h-bond' +  str(pos_counter)+str(k)+str(l),  'mutant_pos_'  + str(mut_resi_pos), 'residue' + str(pos_counter)+str(l), "3.5", mode="2")
							D3 = get_raw_distances('mutant_h-bond' +  str(pos_counter)+str(k)+str(l))
							mutant_contacts[str(k) + ';' + str(pos_counter)+ ','+ str(l)] = (len(D3))
					cmd.reinitialize()
					cmd.load(model_path)
					cmd.select('model_pos_'  + str(mut_resi_pos) , 'resn ' + str(self.three_letter[initial_residue]) + ' and resi ' +  str(mut_resi_pos))
					for m in largest_seq:
						pos_counter2 +=1
						for n in chains:
							cmd.select('residue' + str(pos_counter2) + str(n), 'resn ' + str(self.three_letter[m]) + ' and resi ' +  str(pos_counter2) + ' and chain ' + str(n))
							cmd.distance('model_h-bond' +  str(pos_counter2)+str(m)+str(n),  'model_pos_'  + str(mut_resi_pos), 'residue' + str(pos_counter2)+str(n), "3.5", mode="2")
							D4 = get_raw_distances('model_h-bond' +  str(pos_counter2)+str(m)+str(n))
							model_contacts[str(m) + ';' + str(pos_counter2)+ ','+ str(n)] = (len(D4))
					for contact2 in mutant_contacts:
						if mutant_contacts[contact2] > 0:
							multi_mutant_contact_dict.setdefault("Mutant Contacts", []).append(contact2)
							multi_mutant_contact_dict.setdefault("No. of Mutant Contacts", []).append(str(mutant_contacts[contact2]))
					for contact in model_contacts:
						if model_contacts[contact] > 0:
							multi_mutant_contact_dict.setdefault('Wild - Type Contacts', []).append(contact)
							multi_mutant_contact_dict.setdefault('No. of Wild - Type Contacts', []).append(str(model_contacts[contact]))
					new_headers = []
					for key in multi_mutant_contact_dict:
						new_key = ''
						for i in key:
							new_key += ' '
						new_headers.append(new_key)
					data_file2 = open(output + '/multiple_intro_mutant_contacts.txt', 'a')
					data_file2.write(tabulate(multi_mutant_contact_dict, headers= new_headers, numalign = "center", stralign = "center", tablefmt = "plain")+ '\n' )
					mutant_contacts.clear()
					model_contacts.clear()
					multi_mutant_contact_dict.clear()
			data_file.close() 