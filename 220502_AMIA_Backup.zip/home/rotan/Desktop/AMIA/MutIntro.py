# Project Title: "Automated computational workflow to prioritize potential resistance variants identified in HIV Integrase Subtype C and CRF02_AG" 
# This script is developed for the fufuillment for Masters at the South African National Bioinformatics Institute at the University of the Western Cape
# The project is funded by the Poliomyelitis Research Foundation and the UWC Ada & Bertie Levenstein Bursary Programme
# Currently any licensing and usage of this software is governed under the regulations of the afore mentioned parties

#Author:	Keaghan Brown (3687524) - MSc Bioinformatics Candidate (3687524@myuwc.ac.za)
#Author:	Ruben Cloete (Supervisor) - Lecturer at South African National Bioinformatics Institute (ruben@sanbi.ac.za)

# This script completes the first objective for The Automated Computational Workflow to Prioritize Potential Resistance Variants Identified in HIV Integrase Subtype C and CRF02_AG

import pymol
from Bio.PDB.PDBParser import PDBParser 
from Bio.PDB.Polypeptide import PPBuilder
import ntpath
import warnings
from Bio import BiopythonWarning
warnings.simplefilter('ignore', BiopythonWarning)
import re
from tkinter import Tk
from tkinter.filedialog import askdirectory
from tkinter.filedialog import askopenfilename
import logging
import os
from pathlib import Path
import pymol

class Mutations:

    def __init__(self):
        self.single_list = {}
        self.multi_list = {}
        self.three_letter ={'V': 'VAL', 'I': 'ILE', 'L': 'LEU', 'E': 'GLU', 'Q': 'GLN', 'D': 'ASP', 'N': 'ASN', 'H': 'HIS', 'W': 'TRP', 'F': 'PHE', 'Y': 'TYR', 'R': 'ARG', 'K': 'LYS', 'S': 'SER', 'T': 'THR', 'M': 'MET', 'A': 'ALA', 'G': 'GLY', 'P': 'PRO', 'C': 'CYS'}
    
    def process_mutant_list(self, mutant_list):
        mut_path = os.path.dirname(mutant_list)
        os.chdir(mut_path)
        if not re.search(r'.txt', mutant_list):
            logging.error("A suitable file formt not supplied for mutations")
            raise Exception("Mutation file not supplied, please view log file")
        if os.path.basename(mutant_list) in os.listdir():
            try:
                print('Attempting to open mutation file') 
                data = open(os.path.basename(mutant_list))
            except:
                print("Could not open mutation list, please view log file")
                logging.error("Could not access mutant file provided")
            else:
                file_data = data.read()
                print('Processing mutation list....')
            try:
                mutation_data = file_data.split('^^^')            
                source = mutation_data[0].split('$')[1]
                mutation_data = mutation_data[1].split('\n')
            except:
                print("Could not processmutation list, please view log file")
                logging.error("Could process mutation list due to incorrect format, please ensure format matches example file")
            for i in mutation_data:
                if '$' not in i and i != '':
                    i.replace('\n', '')
                    self.single_list.setdefault(source, []).append(i)
                    self.multi_list.setdefault(source, []).append(i)
            print('Processed!')
            logging.info("Mutation list provided has been processed")
            logging.info("A total of " + str(len(self.single_list[source])) + " mutations have been identified") 

    # The script above, attempts to retrieve a user specified list of mutations in a standard .txt file. The format of the file is as follows: '$' denotes the source of the mutations and for which drug they correlate to, '^^^'  denotes the start of the mutation list. Once each subset has been seperated, they are added to a dictionary which will be used by other functions for mutation introduction
        
    def single_mutations(self, model, output):
        model_path = os.path.dirname(model)
        os.chdir(model_path)
        logging.info("SINGLE MUTATION INTRODUCTION METHOD IS RUNNING....")
        if not re.search(r'.pdb',model):
            logging.error("A suitable PDB file was not supplied for mutation introduction")
            raise Exception("PDB file not supplied, please view log file")
        if os.path.basename(model) in os.listdir():
            structure_id = os.path.basename(model)
            file_name = os.path.basename(model)
            parser = PDBParser(PERMISSIVE = 1)
            structure = parser.get_structure(structure_id, file_name)
            ppbuilder = PPBuilder()
            sequences = []
            for pp in ppbuilder.build_peptides(structure):
                sequence= pp.get_sequence()
                sequences.append(sequence)
                chain_start_pos = pp[0].get_id()[1] 
            largest_seq =  ''
            mut_intro_count = 0
            for i in  sequences:
                if len(i) > len(largest_seq):
                    largest_seq = i
            for key in self.single_list:
                for mutation in self.single_list[key]:
                    print('Attempting to introduce ' + mutation + '  mutation....') 
                    initial_residue = mutation[0]
                    mutated_residue = mutation[len(mutation)-1]
                    residue_pos = mutation[1:len(mutation)-1]
                    if int(residue_pos) <= int(len(largest_seq)):
                        mut_intro_count +=1
                        pymol.cmd.reinitialize()
                        pymol.cmd.load(model)
                        for i in pymol.cmd.get_chains(ntpath.basename(model).split('.')[0]):
                            pymol.cmd.select('mutant_' + mutation, 'resn ' + str(self.three_letter[initial_residue]) + ' and resi ' + residue_pos)
                            pymol.cmd.wizard('mutagenesis')
                            pymol.cmd.refresh_wizard()
                            pymol.cmd.get_wizard().do_select("/" + 'mutant_' + mutation + "//" + i  + "/" + residue_pos + "/")
                            pymol.cmd.get_wizard().set_mode(self.three_letter[mutated_residue])
                            pymol.cmd.get_wizard().apply()
                            print(mutation + '  mutation successfully introduced') 
                            print('Attempting to energy minimize ' + str(mutation) + '.pdb structure....')
                        pymol.cmd.select('mutation',  'resn ' + str(self.three_letter[initial_residue]) + ' and resi ' + str(residue_pos) + ' around 3')
                        pymol.cmd.clean('mutation')
                        pymol.cmd.set_wizard()
                        print(str(mutation) + '.pdb structure minimized!')
                        os.chdir(output)
                        print('Attempting to generate ' + str(mutation) + '.pdb structure....')
                        logging.info("Mutation " + mutation + " PDB was successfully generated from the WT structure!")
                        pymol.cmd.save(str(mutation) + '.pdb')
                        print(str(mutation) + '.pdb structure saved to ' + output)
                    elif int(residue_pos) > int(len(largest_seq)):
                        print('Failed to introduce ' + mutation + '  mutation, please view log file') 
                        logging.error("Mutation " + mutation + " position exceeds chain length")
                logging.info(str(mut_intro_count )+ " out of " + str(len(self.single_list[key])) + " mutations have been successfully introduced")
   # The script above, attempts to introduce the previosly obtained mutations, individually into the supplied PDB structure by reloading the WT structure with each mutant. Each mutation is processed into the initial residue, residue poition and mutated residue. The script runs through each chain in the PDB and specifically selects the initial residue and position and stores it as an object, which ensures that only residues are mutated and not DNA, ligands or ions. The script then calls on the mutagenesis wizard to mutate the selected residues in the object from the initial residue to the mutant. As PyMOL automatically selects the rotamer with the least sterich clashes, we can employ the programs built-in FF to minimize the rersidue and surrounding region (3A) afterwhich the script generates a mutated PDB in a user specified folder
        
        
    def multi_mutations(self, model, output):
        model_path = os.path.dirname(model)
        os.chdir(model_path)
        multi_mutant_list = ''
        pymol.cmd.reinitialize()
        logging.info("MULTIPLE MUTATION INTRODUCTION METHOD IS RUNNING....")
        if not re.search(r'.pdb',model):
            logging.error("A suitable PDB file was not supplied for mutation introduction")
            raise Exception("PDB file not supplied, please view log file")
        if os.path.basename(model) in os.listdir():
            structure_id = os.path.basename(model)
            file_name = os.path.basename(model)
            parser = PDBParser(PERMISSIVE = 1)
            structure = parser.get_structure(structure_id, file_name)
            ppbuilder = PPBuilder()
            sequences = []
            for pp in ppbuilder.build_peptides(structure):
                sequence= pp.get_sequence()
                sequences.append(sequence)
                chain_start_pos = pp[0].get_id()[1] 
            largest_seq =  ''
            mut_intro_count = 0
            for i in  sequences:
                if len(i) > len(largest_seq):
                    largest_seq = i
            mutant_pos_list = []
            pymol.cmd.load(model)
            identical_position_mutations = []
            for key in self.multi_list:
                for mutation in self.multi_list[key]:
                    initial_residue = mutation[0]
                    mutated_residue = mutation[len(mutation)-1]
                    residue_pos = mutation[1:len(mutation)-1]
                    for mutation2 in  self.multi_list[key]:
                        residue_pos2 = mutation2[1:len(mutation2)-1]
                        if mutation2 != mutation and residue_pos == residue_pos2 and re.search(residue_pos, mutation2):
                            identical_position_mutations.append(mutation2)
                    if residue_pos not in mutant_pos_list:
                        mutant_pos_list.append(residue_pos)
                    elif residue_pos in mutant_pos_list:
                        identical_position_mutations.remove(mutation)
            for dbl_pos_mut in identical_position_mutations:
                self.multi_list[key].remove(dbl_pos_mut)
                logging.warning("Mutation " + dbl_pos_mut + " was replaced by another mutation at the same position")
            for key in self.multi_list:
                for mutation in self.multi_list[key]:
                    print('Attempting to introduce ' + mutation + '  mutation....') 
                    initial_residue = mutation[0]
                    mutated_residue = mutation[len(mutation)-1]
                    residue_pos = mutation[1:len(mutation)-1]
                    if int(residue_pos) <= int(len(largest_seq)):
                        mut_intro_count +=1
                        multi_mutant_list += mutation + '_'
                        for i in pymol.cmd.get_chains(ntpath.basename(model).split('.')[0]):
                            pymol.cmd.select('mutant_' + mutation, 'resn ' + str(self.three_letter[initial_residue]) + ' and resi ' + residue_pos)
                            pymol.cmd.wizard('mutagenesis')
                            pymol.cmd.refresh_wizard()
                            pymol.cmd.get_wizard().do_select("/" + 'mutant_' + mutation + "//" + i  + "/" + residue_pos + "/")
                            pymol.cmd.get_wizard().set_mode(self.three_letter[mutated_residue])
                            pymol.cmd.get_wizard().apply()
                            print(mutation + '  mutation successfully introduced') 
                            print('Attempting to energy minimize ' + str(mutation) + '.pdb structure....')
                        pymol.cmd.select('mutation',  'resn ' + str(self.three_letter[initial_residue]) + ' and resi ' + str(residue_pos) + ' around 3')
                        pymol.cmd.clean('mutation')
                        pymol.cmd.set_wizard()
                        print(str(mutation) + '.pdb structure minimized!')
                        logging.info("Mutation " + mutation + " PDB was successfully generated from the WT structure!")
                    elif int(residue_pos) > int(len(largest_seq)):
                        print('Failed to introduce ' + mutation + '  mutation, please view log file') 
                        logging.error("Mutation " + mutation + " position exceeds chain length")
                logging.info(str(mut_intro_count )+ " out of " + str(len(self.single_list[key])) + " mutations have been successfully introduced")
                os.chdir(output)
                print('Attempting to generate ' + str(mutation) + '.pdb structure....')
                pymol.cmd.save(str(multi_mutant_list) + '.pdb')
                print(str(multi_mutant_list) + '.pdb structure saved to ' + output)
 # The script above, attempts to introduce the previosly obtained mutations, all at once into the supplied PDB structure by loading the WT structure prior to introducing each mutant. Each mutation is processed into the initial residue, residue poition and mutated residue. The script runs through each chain in the PDB and specifically selects the initial residue and position and stores it as an object, which ensures that only residues are mutated and not DNA, ligands or ions. The script then calls on the mutagenesis wizard to mutate the selected residues in the object from the initial residue to the mutant. As PyMOL automatically selects the rotamer with the least sterich clashes, we can employ the programs built-in FF to minimize the rersidue and surrounding region (3A) afterwhich the script generates a mutated PDB in the user specified folder
        
          
